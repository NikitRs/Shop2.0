


$(document).ready(function () {
    $("#buy").click(function () {
        if (colvo.value == 1)
        notie.alert({ type: 'success', text: "В корзину добавили " + colvo.value + " товар!", time: 2 });
        else if (colvo.value == 2 || 3 || 4 )
        notie.alert({ type: 'success', text: "В корзину добавили " + colvo.value + " товара!", time: 2 });
        else 
        notie.alert({ type: 'success', text: "В корзину добавили " + colvo.value + " товаров!", time: 2 });
        });
    });


    

$(document).ready(function () {
    $("#favorite").click(function () {
        notie.alert({ type:4, text:"Вы добавили товар в избранное."});
         });
    });

$(document).ready(function () {
    $("#plus").click(function() {
        colvo.value++;});});

$(document).ready(function () {
     $("#minus").click(function() {
        if (colvo.value > 1){
        colvo.value--;}});});
